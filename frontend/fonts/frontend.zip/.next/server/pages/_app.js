/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./src/contexts/AuthContext.tsx":
/*!**************************************!*\
  !*** ./src/contexts/AuthContext.tsx ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"AuthContext\": () => (/* binding */ AuthContext),\n/* harmony export */   \"signOut\": () => (/* binding */ signOut),\n/* harmony export */   \"AuthProvider\": () => (/* binding */ AuthProvider)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _services_apiClient__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/apiClient */ \"./src/services/apiClient.ts\");\n/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! nookies */ \"nookies\");\n/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\nconst AuthContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({});\nfunction signOut() {\n    try {\n        (0,nookies__WEBPACK_IMPORTED_MODULE_3__.destroyCookie)(undefined, '@nextauth.token');\n        next_router__WEBPACK_IMPORTED_MODULE_4___default().push('/');\n    } catch  {\n        console.log('erro ao deslogar');\n    }\n}\nfunction AuthProvider({ children  }) {\n    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();\n    const isAuthenticated = !!user;\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        // tentar pegar algo no cookie\n        const { '@nextauth.token': token  } = (0,nookies__WEBPACK_IMPORTED_MODULE_3__.parseCookies)();\n        if (token) {\n            _services_apiClient__WEBPACK_IMPORTED_MODULE_2__.api.get('/me').then((response)=>{\n                const { id , name , email  } = response.data;\n                setUser({\n                    id,\n                    name,\n                    email\n                });\n            }).catch(()=>{\n                //Se deu erro deslogamos o user.\n                signOut();\n            });\n        }\n    }, []);\n    async function signIn({ email , password  }) {\n        try {\n            const response = await _services_apiClient__WEBPACK_IMPORTED_MODULE_2__.api.post('/session', {\n                email,\n                password\n            });\n            // console.log(response.data);\n            const { id , name , token  } = response.data;\n            (0,nookies__WEBPACK_IMPORTED_MODULE_3__.setCookie)(undefined, '@nextauth.token', token, {\n                maxAge: 60 * 60 * 24 * 30,\n                path: \"/\" // Quais caminhos terao acesso ao cookie\n            });\n            setUser({\n                id,\n                name,\n                email\n            });\n            //Passar para proximas requisiçoes o nosso token\n            _services_apiClient__WEBPACK_IMPORTED_MODULE_2__.api.defaults.headers.Authorization = `Bearer ${token}`;\n            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.success('Logado com sucesso!');\n            //Redirecionar o user para /dashboard\n            next_router__WEBPACK_IMPORTED_MODULE_4___default().push('/dashboard');\n        } catch (err) {\n            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(\"Erro ao acessar!\");\n            console.log(\"ERRO AO ACESSAR \", err);\n        }\n    }\n    async function signUp({ name , email , password  }) {\n        try {\n            const response = await _services_apiClient__WEBPACK_IMPORTED_MODULE_2__.api.post('/users', {\n                name,\n                email,\n                password\n            });\n            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.success(\"Conta criada com sucesso!\");\n            next_router__WEBPACK_IMPORTED_MODULE_4___default().push('/');\n        } catch (err) {\n            react_toastify__WEBPACK_IMPORTED_MODULE_5__.toast.error(\"Erro ao cadastrar!\");\n            console.log(\"erro ao cadastrar \", err);\n        }\n    }\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(AuthContext.Provider, {\n        value: {\n            user,\n            isAuthenticated,\n            signIn,\n            signOut,\n            signUp\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"D:\\\\curso\\\\pizzaria\\\\frontend\\\\src\\\\contexts\\\\AuthContext.tsx\",\n        lineNumber: 138,\n        columnNumber: 5\n    }, this));\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29udGV4dHMvQXV0aENvbnRleHQudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFxRTtBQUUxQjtBQUVxQjtBQUNoQztBQUVNO0FBZ0MvQixLQUFLLENBQUNTLFdBQVcsaUJBQUdULG9EQUFhLENBQUMsQ0FBQyxDQUFDO0FBR3BDLFNBQVNVLE9BQU8sR0FBRSxDQUFDO0lBQ3hCLEdBQUcsRUFBQztRQUNGTixzREFBYSxDQUFDTyxTQUFTLEVBQUUsQ0FBaUI7UUFDMUNKLHVEQUFXLENBQUMsQ0FBRztJQUNqQixDQUFDLE1BQUssR0FBQztRQUNMTSxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFrQjtJQUNoQyxDQUFDO0FBQ0gsQ0FBQztBQUVNLFNBQVNDLFlBQVksQ0FBQyxDQUFDLENBQUNDLFFBQVEsRUFBb0IsQ0FBQyxFQUFDLENBQUM7SUFDNUQsS0FBSyxNQUFFQyxJQUFJLE1BQUVDLE9BQU8sTUFBSWpCLCtDQUFRO0lBQ2hDLEtBQUssQ0FBQ2tCLGVBQWUsS0FBS0YsSUFBSTtJQUU5QmYsZ0RBQVMsS0FBTyxDQUFDO1FBRWYsRUFBOEI7UUFDOUIsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFpQixrQkFBRWtCLEtBQUssRUFBQyxDQUFDLEdBQUdkLHFEQUFZO1FBRWpELEVBQUUsRUFBQ2MsS0FBSyxFQUFDLENBQUM7WUFDUmpCLHdEQUFPLENBQUMsQ0FBSyxNQUFFbUIsSUFBSSxFQUFDQyxRQUFRLEdBQUksQ0FBQztnQkFDL0IsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsRUFBRSxHQUFFQyxJQUFJLEdBQUVDLEtBQUssRUFBQyxDQUFDLEdBQUdILFFBQVEsQ0FBQ0ksSUFBSTtnQkFFekNULE9BQU8sQ0FBQyxDQUFDO29CQUNQTSxFQUFFO29CQUNGQyxJQUFJO29CQUNKQyxLQUFLO2dCQUNQLENBQUM7WUFFSCxDQUFDLEVBQ0FFLEtBQUssS0FBTyxDQUFDO2dCQUNaLEVBQWdDO2dCQUNoQ2xCLE9BQU87WUFDVCxDQUFDO1FBQ0gsQ0FBQztJQUdILENBQUMsRUFBRSxDQUFDLENBQUM7bUJBRVVtQixNQUFNLENBQUMsQ0FBQyxDQUFDSCxLQUFLLEdBQUVJLFFBQVEsRUFBYyxDQUFDLEVBQUMsQ0FBQztRQUN0RCxHQUFHLEVBQUM7WUFDRixLQUFLLENBQUNQLFFBQVEsR0FBRyxLQUFLLENBQUNwQix5REFBUSxDQUFDLENBQVUsV0FBRSxDQUFDO2dCQUMzQ3VCLEtBQUs7Z0JBQ0xJLFFBQVE7WUFDVixDQUFDO1lBQ0QsRUFBOEI7WUFFOUIsS0FBSyxDQUFDLENBQUMsQ0FBQ04sRUFBRSxHQUFFQyxJQUFJLEdBQUVMLEtBQUssRUFBQyxDQUFDLEdBQUdHLFFBQVEsQ0FBQ0ksSUFBSTtZQUV6Q3RCLGtEQUFTLENBQUNNLFNBQVMsRUFBRSxDQUFpQixrQkFBRVMsS0FBSyxFQUFFLENBQUM7Z0JBQzlDWSxNQUFNLEVBQUUsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRTtnQkFDekJDLElBQUksRUFBRSxDQUFHLEVBQUMsQ0FBd0M7WUFDcEQsQ0FBQztZQUVEZixPQUFPLENBQUMsQ0FBQztnQkFDUE0sRUFBRTtnQkFDRkMsSUFBSTtnQkFDSkMsS0FBSztZQUNQLENBQUM7WUFFRCxFQUFnRDtZQUNoRHZCLG1GQUFvQyxJQUFLLE9BQU8sRUFBRWlCLEtBQUs7WUFFdkRaLHlEQUFhLENBQUMsQ0FBcUI7WUFFbkMsRUFBcUM7WUFDckNELHVEQUFXLENBQUMsQ0FBWTtRQUcxQixDQUFDLE1BQUssRUFBQzhCLEdBQUcsRUFBQyxDQUFDO1lBQ1Y3Qix1REFBVyxDQUFDLENBQWtCO1lBQzlCSyxPQUFPLENBQUNDLEdBQUcsQ0FBQyxDQUFrQixtQkFBRXVCLEdBQUc7UUFDckMsQ0FBQztJQUNILENBQUM7bUJBR2NFLE1BQU0sQ0FBQyxDQUFDLENBQUNkLElBQUksR0FBRUMsS0FBSyxHQUFFSSxRQUFRLEVBQWEsQ0FBQyxFQUFDLENBQUM7UUFDM0QsR0FBRyxFQUFDO1lBRUYsS0FBSyxDQUFDUCxRQUFRLEdBQUcsS0FBSyxDQUFDcEIseURBQVEsQ0FBQyxDQUFRLFNBQUUsQ0FBQztnQkFDekNzQixJQUFJO2dCQUNKQyxLQUFLO2dCQUNMSSxRQUFRO1lBQ1YsQ0FBQztZQUVEdEIseURBQWEsQ0FBQyxDQUEyQjtZQUV6Q0QsdURBQVcsQ0FBQyxDQUFHO1FBRWpCLENBQUMsTUFBSyxFQUFDOEIsR0FBRyxFQUFDLENBQUM7WUFDVjdCLHVEQUFXLENBQUMsQ0FBb0I7WUFDaENLLE9BQU8sQ0FBQ0MsR0FBRyxDQUFDLENBQW9CLHFCQUFFdUIsR0FBRztRQUN2QyxDQUFDO0lBQ0gsQ0FBQztJQUVELE1BQU0sNkVBQ0g1QixXQUFXLENBQUMrQixRQUFRO1FBQUNDLEtBQUssRUFBRSxDQUFDO1lBQUN4QixJQUFJO1lBQUVFLGVBQWU7WUFBRVUsTUFBTTtZQUFFbkIsT0FBTztZQUFFNkIsTUFBTTtRQUFDLENBQUM7a0JBQzVFdkIsUUFBUTs7Ozs7O0FBR2YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250ZW5kLy4vc3JjL2NvbnRleHRzL0F1dGhDb250ZXh0LnRzeD8xZmEyIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIFJlYWN0Tm9kZSwgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gJ3JlYWN0JztcclxuXHJcbmltcG9ydCB7IGFwaSB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaUNsaWVudCc7XHJcblxyXG5pbXBvcnQgeyBkZXN0cm95Q29va2llLCBzZXRDb29raWUsIHBhcnNlQ29va2llcyB9IGZyb20gJ25vb2tpZXMnXHJcbmltcG9ydCBSb3V0ZXIgZnJvbSAnbmV4dC9yb3V0ZXInO1xyXG5cclxuaW1wb3J0IHsgdG9hc3QgfSBmcm9tICdyZWFjdC10b2FzdGlmeSdcclxuXHJcblxyXG50eXBlIEF1dGhDb250ZXh0RGF0YSA9IHtcclxuICB1c2VyOiBVc2VyUHJvcHM7XHJcbiAgaXNBdXRoZW50aWNhdGVkOiBib29sZWFuO1xyXG4gIHNpZ25JbjogKGNyZWRlbnRpYWxzOiBTaWduSW5Qcm9wcykgPT4gUHJvbWlzZTx2b2lkPjtcclxuICBzaWduT3V0OiAoKSA9PiB2b2lkO1xyXG4gIHNpZ25VcDogKGNyZWRlbnRpYWxzOiBTaWduVXBQcm9wcykgPT4gUHJvbWlzZTx2b2lkPjtcclxufVxyXG5cclxudHlwZSBVc2VyUHJvcHMgPSB7XHJcbiAgaWQ6IHN0cmluZztcclxuICBuYW1lOiBzdHJpbmc7XHJcbiAgZW1haWw6IHN0cmluZztcclxufVxyXG5cclxudHlwZSBTaWduSW5Qcm9wcyA9IHtcclxuICBlbWFpbDogc3RyaW5nO1xyXG4gIHBhc3N3b3JkOiBzdHJpbmc7XHJcbn1cclxuXHJcbnR5cGUgU2lnblVwUHJvcHMgPSB7XHJcbiAgbmFtZTogc3RyaW5nO1xyXG4gIGVtYWlsOiBzdHJpbmc7XHJcbiAgcGFzc3dvcmQ6IHN0cmluZztcclxufVxyXG5cclxudHlwZSBBdXRoUHJvdmlkZXJQcm9wcyA9IHtcclxuICBjaGlsZHJlbjogUmVhY3ROb2RlO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgQXV0aENvbnRleHQgPSBjcmVhdGVDb250ZXh0KHt9IGFzIEF1dGhDb250ZXh0RGF0YSlcclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gc2lnbk91dCgpe1xyXG4gIHRyeXtcclxuICAgIGRlc3Ryb3lDb29raWUodW5kZWZpbmVkLCAnQG5leHRhdXRoLnRva2VuJylcclxuICAgIFJvdXRlci5wdXNoKCcvJylcclxuICB9Y2F0Y2h7XHJcbiAgICBjb25zb2xlLmxvZygnZXJybyBhbyBkZXNsb2dhcicpXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHsgY2hpbGRyZW4gfTogQXV0aFByb3ZpZGVyUHJvcHMpe1xyXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXJQcm9wcz4oKVxyXG4gIGNvbnN0IGlzQXV0aGVudGljYXRlZCA9ICEhdXNlcjtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuXHJcbiAgICAvLyB0ZW50YXIgcGVnYXIgYWxnbyBubyBjb29raWVcclxuICAgIGNvbnN0IHsgJ0BuZXh0YXV0aC50b2tlbic6IHRva2VuIH0gPSBwYXJzZUNvb2tpZXMoKTtcclxuXHJcbiAgICBpZih0b2tlbil7XHJcbiAgICAgIGFwaS5nZXQoJy9tZScpLnRoZW4ocmVzcG9uc2UgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgaWQsIG5hbWUsIGVtYWlsIH0gPSByZXNwb25zZS5kYXRhO1xyXG5cclxuICAgICAgICBzZXRVc2VyKHtcclxuICAgICAgICAgIGlkLFxyXG4gICAgICAgICAgbmFtZSxcclxuICAgICAgICAgIGVtYWlsXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoKSA9PiB7XHJcbiAgICAgICAgLy9TZSBkZXUgZXJybyBkZXNsb2dhbW9zIG8gdXNlci5cclxuICAgICAgICBzaWduT3V0KCk7XHJcbiAgICAgIH0pXHJcbiAgICB9XHJcblxyXG5cclxuICB9LCBbXSlcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gc2lnbkluKHsgZW1haWwsIHBhc3N3b3JkIH06IFNpZ25JblByb3BzKXtcclxuICAgIHRyeXtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBhcGkucG9zdCgnL3Nlc3Npb24nLCB7XHJcbiAgICAgICAgZW1haWwsXHJcbiAgICAgICAgcGFzc3dvcmRcclxuICAgICAgfSlcclxuICAgICAgLy8gY29uc29sZS5sb2cocmVzcG9uc2UuZGF0YSk7XHJcblxyXG4gICAgICBjb25zdCB7IGlkLCBuYW1lLCB0b2tlbiB9ID0gcmVzcG9uc2UuZGF0YTtcclxuXHJcbiAgICAgIHNldENvb2tpZSh1bmRlZmluZWQsICdAbmV4dGF1dGgudG9rZW4nLCB0b2tlbiwge1xyXG4gICAgICAgIG1heEFnZTogNjAgKiA2MCAqIDI0ICogMzAsIC8vIEV4cGlyYXIgZW0gMSBtZXNcclxuICAgICAgICBwYXRoOiBcIi9cIiAvLyBRdWFpcyBjYW1pbmhvcyB0ZXJhbyBhY2Vzc28gYW8gY29va2llXHJcbiAgICAgIH0pXHJcblxyXG4gICAgICBzZXRVc2VyKHtcclxuICAgICAgICBpZCxcclxuICAgICAgICBuYW1lLFxyXG4gICAgICAgIGVtYWlsLFxyXG4gICAgICB9KVxyXG5cclxuICAgICAgLy9QYXNzYXIgcGFyYSBwcm94aW1hcyByZXF1aXNpw6dvZXMgbyBub3NzbyB0b2tlblxyXG4gICAgICBhcGkuZGVmYXVsdHMuaGVhZGVyc1snQXV0aG9yaXphdGlvbiddID0gYEJlYXJlciAke3Rva2VufWBcclxuXHJcbiAgICAgIHRvYXN0LnN1Y2Nlc3MoJ0xvZ2FkbyBjb20gc3VjZXNzbyEnKVxyXG5cclxuICAgICAgLy9SZWRpcmVjaW9uYXIgbyB1c2VyIHBhcmEgL2Rhc2hib2FyZFxyXG4gICAgICBSb3V0ZXIucHVzaCgnL2Rhc2hib2FyZCcpXHJcblxyXG5cclxuICAgIH1jYXRjaChlcnIpe1xyXG4gICAgICB0b2FzdC5lcnJvcihcIkVycm8gYW8gYWNlc3NhciFcIilcclxuICAgICAgY29uc29sZS5sb2coXCJFUlJPIEFPIEFDRVNTQVIgXCIsIGVycilcclxuICAgIH1cclxuICB9XHJcblxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBzaWduVXAoeyBuYW1lLCBlbWFpbCwgcGFzc3dvcmR9OiBTaWduVXBQcm9wcyl7XHJcbiAgICB0cnl7XHJcbiAgICAgIFxyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGFwaS5wb3N0KCcvdXNlcnMnLCB7XHJcbiAgICAgICAgbmFtZSxcclxuICAgICAgICBlbWFpbCxcclxuICAgICAgICBwYXNzd29yZFxyXG4gICAgICB9KVxyXG5cclxuICAgICAgdG9hc3Quc3VjY2VzcyhcIkNvbnRhIGNyaWFkYSBjb20gc3VjZXNzbyFcIilcclxuXHJcbiAgICAgIFJvdXRlci5wdXNoKCcvJylcclxuXHJcbiAgICB9Y2F0Y2goZXJyKXtcclxuICAgICAgdG9hc3QuZXJyb3IoXCJFcnJvIGFvIGNhZGFzdHJhciFcIilcclxuICAgICAgY29uc29sZS5sb2coXCJlcnJvIGFvIGNhZGFzdHJhciBcIiwgZXJyKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuKFxyXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IHVzZXIsIGlzQXV0aGVudGljYXRlZCwgc2lnbkluLCBzaWduT3V0LCBzaWduVXAgfX0+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XHJcbiAgKVxyXG59Il0sIm5hbWVzIjpbImNyZWF0ZUNvbnRleHQiLCJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsImFwaSIsImRlc3Ryb3lDb29raWUiLCJzZXRDb29raWUiLCJwYXJzZUNvb2tpZXMiLCJSb3V0ZXIiLCJ0b2FzdCIsIkF1dGhDb250ZXh0Iiwic2lnbk91dCIsInVuZGVmaW5lZCIsInB1c2giLCJjb25zb2xlIiwibG9nIiwiQXV0aFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJ1c2VyIiwic2V0VXNlciIsImlzQXV0aGVudGljYXRlZCIsInRva2VuIiwiZ2V0IiwidGhlbiIsInJlc3BvbnNlIiwiaWQiLCJuYW1lIiwiZW1haWwiLCJkYXRhIiwiY2F0Y2giLCJzaWduSW4iLCJwYXNzd29yZCIsInBvc3QiLCJtYXhBZ2UiLCJwYXRoIiwiZGVmYXVsdHMiLCJoZWFkZXJzIiwic3VjY2VzcyIsImVyciIsImVycm9yIiwic2lnblVwIiwiUHJvdmlkZXIiLCJ2YWx1ZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/contexts/AuthContext.tsx\n");

/***/ }),

/***/ "./src/pages/_app.tsx":
/*!****************************!*\
  !*** ./src/pages/_app.tsx ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../styles/globals.scss */ \"./styles/globals.scss\");\n/* harmony import */ var _styles_globals_scss__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_scss__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-toastify */ \"react-toastify\");\n/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-toastify/dist/ReactToastify.css */ \"./node_modules/react-toastify/dist/ReactToastify.css\");\n/* harmony import */ var react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_toastify_dist_ReactToastify_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../contexts/AuthContext */ \"./src/contexts/AuthContext.tsx\");\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_4__.AuthProvider, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                ...pageProps\n            }, void 0, false, {\n                fileName: \"D:\\\\curso\\\\pizzaria\\\\frontend\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 11,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_toastify__WEBPACK_IMPORTED_MODULE_2__.ToastContainer, {\n                autoClose: 3000\n            }, void 0, false, {\n                fileName: \"D:\\\\curso\\\\pizzaria\\\\frontend\\\\src\\\\pages\\\\_app.tsx\",\n                lineNumber: 12,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"D:\\\\curso\\\\pizzaria\\\\frontend\\\\src\\\\pages\\\\_app.tsx\",\n        lineNumber: 10,\n        columnNumber: 4\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvcGFnZXMvX2FwcC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7QUFBa0M7QUFFYTtBQUNEO0FBRVE7U0FFN0NFLEtBQUssQ0FBQyxDQUFDLENBQUNDLFNBQVMsR0FBRUMsU0FBUyxFQUFXLENBQUMsRUFBRSxDQUFDO0lBQ2xELE1BQU0sNkVBQ0pILCtEQUFZOzt3RkFDVEUsU0FBUzttQkFBS0MsU0FBUzs7Ozs7O3dGQUN2QkosMERBQWM7Z0JBQUNLLFNBQVMsRUFBRSxJQUFJOzs7Ozs7Ozs7Ozs7QUFHckMsQ0FBQztBQUVELGlFQUFlSCxLQUFLIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZnJvbnRlbmQvLi9zcmMvcGFnZXMvX2FwcC50c3g/ZjlkNiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgJy4uLy4uL3N0eWxlcy9nbG9iYWxzLnNjc3MnXG5pbXBvcnQgeyBBcHBQcm9wcyB9IGZyb20gJ25leHQvYXBwJztcbmltcG9ydCB7IFRvYXN0Q29udGFpbmVyIH0gZnJvbSAncmVhY3QtdG9hc3RpZnknXG5pbXBvcnQgJ3JlYWN0LXRvYXN0aWZ5L2Rpc3QvUmVhY3RUb2FzdGlmeS5jc3MnO1xuXG5pbXBvcnQgeyBBdXRoUHJvdmlkZXIgfSBmcm9tICcuLi9jb250ZXh0cy9BdXRoQ29udGV4dCdcblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9OiBBcHBQcm9wcykge1xuICByZXR1cm4gKFxuICAgPEF1dGhQcm92aWRlcj5cbiAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cbiAgICAgIDxUb2FzdENvbnRhaW5lciBhdXRvQ2xvc2U9ezMwMDB9IC8+XG4gICA8L0F1dGhQcm92aWRlcj5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBNeUFwcFxuIl0sIm5hbWVzIjpbIlRvYXN0Q29udGFpbmVyIiwiQXV0aFByb3ZpZGVyIiwiTXlBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJhdXRvQ2xvc2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/pages/_app.tsx\n");

/***/ }),

/***/ "./src/services/api.ts":
/*!*****************************!*\
  !*** ./src/services/api.ts ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"setupAPIClient\": () => (/* binding */ setupAPIClient)\n/* harmony export */ });\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! nookies */ \"nookies\");\n/* harmony import */ var nookies__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(nookies__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _errors_AuthTokenError__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./errors/AuthTokenError */ \"./src/services/errors/AuthTokenError.ts\");\n/* harmony import */ var _contexts_AuthContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../contexts/AuthContext */ \"./src/contexts/AuthContext.tsx\");\n\n\n\n\nfunction setupAPIClient(ctx = undefined) {\n    let cookies = (0,nookies__WEBPACK_IMPORTED_MODULE_1__.parseCookies)(ctx);\n    const api = axios__WEBPACK_IMPORTED_MODULE_0___default().create({\n        baseURL: 'http://localhost:3333',\n        headers: {\n            Authorization: `Bearer ${cookies['@nextauth.token']}`\n        }\n    });\n    api.interceptors.response.use((response)=>{\n        return response;\n    }, (error)=>{\n        if (error.response.status === 401) {\n            // qualquer erro 401 (nao autorizado) devemos deslogar o usuario\n            if (true) {\n                // Chamar a funçao para deslogar o usuario\n                (0,_contexts_AuthContext__WEBPACK_IMPORTED_MODULE_3__.signOut)();\n            } else {}\n        }\n        return Promise.reject(error);\n    });\n    return api;\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc2VydmljZXMvYXBpLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBeUM7QUFDSDtBQUNrQjtBQUVQO0FBRTFDLFNBQVNJLGNBQWMsQ0FBQ0MsR0FBRyxHQUFHQyxTQUFTLEVBQUMsQ0FBQztJQUM5QyxHQUFHLENBQUNDLE9BQU8sR0FBR04scURBQVksQ0FBQ0ksR0FBRztJQUU5QixLQUFLLENBQUNHLEdBQUcsR0FBR1IsbURBQVksQ0FBQyxDQUFDO1FBQ3hCVSxPQUFPLEVBQUUsQ0FBdUI7UUFDaENDLE9BQU8sRUFBRSxDQUFDO1lBQ1JDLGFBQWEsR0FBRyxPQUFPLEVBQUVMLE9BQU8sQ0FBQyxDQUFpQjtRQUNwRCxDQUFDO0lBQ0gsQ0FBQztJQUVEQyxHQUFHLENBQUNLLFlBQVksQ0FBQ0MsUUFBUSxDQUFDQyxHQUFHLEVBQUNELFFBQVEsR0FBSSxDQUFDO1FBQ3pDLE1BQU0sQ0FBQ0EsUUFBUTtJQUNqQixDQUFDLEdBQUdFLEtBQWlCLEdBQUssQ0FBQztRQUN6QixFQUFFLEVBQUNBLEtBQUssQ0FBQ0YsUUFBUSxDQUFDRyxNQUFNLEtBQUssR0FBRyxFQUFDLENBQUM7WUFDaEMsRUFBZ0U7WUFDaEUsRUFBRSxFQUFDLElBQTJCLEVBQUMsQ0FBQztnQkFDOUIsRUFBMEM7Z0JBQzFDZCw4REFBTztZQUNULENBQUMsTUFBSSxFQUVKO1FBQ0gsQ0FBQztRQUVELE1BQU0sQ0FBQ2UsT0FBTyxDQUFDQyxNQUFNLENBQUNILEtBQUs7SUFFN0IsQ0FBQztJQUVELE1BQU0sQ0FBQ1IsR0FBRztBQUVaLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9mcm9udGVuZC8uL3NyYy9zZXJ2aWNlcy9hcGkudHM/OTU2ZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MsIHsgQXhpb3NFcnJvciB9IGZyb20gJ2F4aW9zJ1xyXG5pbXBvcnQgeyBwYXJzZUNvb2tpZXMgfSBmcm9tICdub29raWVzJ1xyXG5pbXBvcnQgeyBBdXRoVG9rZW5FcnJvciB9IGZyb20gJy4vZXJyb3JzL0F1dGhUb2tlbkVycm9yJ1xyXG5cclxuaW1wb3J0IHsgc2lnbk91dCB9IGZyb20gJy4uL2NvbnRleHRzL0F1dGhDb250ZXh0J1xyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHNldHVwQVBJQ2xpZW50KGN0eCA9IHVuZGVmaW5lZCl7XHJcbiAgbGV0IGNvb2tpZXMgPSBwYXJzZUNvb2tpZXMoY3R4KTtcclxuXHJcbiAgY29uc3QgYXBpID0gYXhpb3MuY3JlYXRlKHtcclxuICAgIGJhc2VVUkw6ICdodHRwOi8vbG9jYWxob3N0OjMzMzMnLFxyXG4gICAgaGVhZGVyczoge1xyXG4gICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7Y29va2llc1snQG5leHRhdXRoLnRva2VuJ119YFxyXG4gICAgfVxyXG4gIH0pXHJcblxyXG4gIGFwaS5pbnRlcmNlcHRvcnMucmVzcG9uc2UudXNlKHJlc3BvbnNlID0+IHtcclxuICAgIHJldHVybiByZXNwb25zZTtcclxuICB9LCAoZXJyb3I6IEF4aW9zRXJyb3IpID0+IHtcclxuICAgIGlmKGVycm9yLnJlc3BvbnNlLnN0YXR1cyA9PT0gNDAxKXtcclxuICAgICAgLy8gcXVhbHF1ZXIgZXJybyA0MDEgKG5hbyBhdXRvcml6YWRvKSBkZXZlbW9zIGRlc2xvZ2FyIG8gdXN1YXJpb1xyXG4gICAgICBpZih0eXBlb2Ygd2luZG93ICE9PSB1bmRlZmluZWQpe1xyXG4gICAgICAgIC8vIENoYW1hciBhIGZ1bsOnYW8gcGFyYSBkZXNsb2dhciBvIHVzdWFyaW9cclxuICAgICAgICBzaWduT3V0KCk7XHJcbiAgICAgIH1lbHNle1xyXG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlamVjdChuZXcgQXV0aFRva2VuRXJyb3IoKSlcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBQcm9taXNlLnJlamVjdChlcnJvcik7XHJcblxyXG4gIH0pXHJcblxyXG4gIHJldHVybiBhcGk7XHJcblxyXG59Il0sIm5hbWVzIjpbImF4aW9zIiwicGFyc2VDb29raWVzIiwiQXV0aFRva2VuRXJyb3IiLCJzaWduT3V0Iiwic2V0dXBBUElDbGllbnQiLCJjdHgiLCJ1bmRlZmluZWQiLCJjb29raWVzIiwiYXBpIiwiY3JlYXRlIiwiYmFzZVVSTCIsImhlYWRlcnMiLCJBdXRob3JpemF0aW9uIiwiaW50ZXJjZXB0b3JzIiwicmVzcG9uc2UiLCJ1c2UiLCJlcnJvciIsInN0YXR1cyIsIlByb21pc2UiLCJyZWplY3QiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/services/api.ts\n");

/***/ }),

/***/ "./src/services/apiClient.ts":
/*!***********************************!*\
  !*** ./src/services/apiClient.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"api\": () => (/* binding */ api)\n/* harmony export */ });\n/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api */ \"./src/services/api.ts\");\n\nconst api = (0,_api__WEBPACK_IMPORTED_MODULE_0__.setupAPIClient)();\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc2VydmljZXMvYXBpQ2xpZW50LnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7O0FBQXNDO0FBRS9CLEtBQUssQ0FBQ0MsR0FBRyxHQUFHRCxvREFBYyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250ZW5kLy4vc3JjL3NlcnZpY2VzL2FwaUNsaWVudC50cz83ZDAxIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHNldHVwQVBJQ2xpZW50IH0gZnJvbSAnLi9hcGknXHJcblxyXG5leHBvcnQgY29uc3QgYXBpID0gc2V0dXBBUElDbGllbnQoKTsiXSwibmFtZXMiOlsic2V0dXBBUElDbGllbnQiLCJhcGkiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/services/apiClient.ts\n");

/***/ }),

/***/ "./src/services/errors/AuthTokenError.ts":
/*!***********************************************!*\
  !*** ./src/services/errors/AuthTokenError.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"AuthTokenError\": () => (/* binding */ AuthTokenError)\n/* harmony export */ });\nclass AuthTokenError extends Error {\n    constructor(){\n        super('Error with authentication token.');\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvc2VydmljZXMvZXJyb3JzL0F1dGhUb2tlbkVycm9yLnRzLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBTyxNQUFNQSxjQUFjLFNBQVNDLEtBQUs7aUJBQzFCLENBQUM7UUFDWixLQUFLLENBQUMsQ0FBa0M7SUFDMUMsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2Zyb250ZW5kLy4vc3JjL3NlcnZpY2VzL2Vycm9ycy9BdXRoVG9rZW5FcnJvci50cz8yM2ViIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjbGFzcyBBdXRoVG9rZW5FcnJvciBleHRlbmRzIEVycm9ye1xyXG4gIGNvbnN0cnVjdG9yKCl7XHJcbiAgICBzdXBlcignRXJyb3Igd2l0aCBhdXRoZW50aWNhdGlvbiB0b2tlbi4nKVxyXG4gIH1cclxufSJdLCJuYW1lcyI6WyJBdXRoVG9rZW5FcnJvciIsIkVycm9yIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./src/services/errors/AuthTokenError.ts\n");

/***/ }),

/***/ "./node_modules/react-toastify/dist/ReactToastify.css":
/*!************************************************************!*\
  !*** ./node_modules/react-toastify/dist/ReactToastify.css ***!
  \************************************************************/
/***/ (() => {



/***/ }),

/***/ "./styles/globals.scss":
/*!*****************************!*\
  !*** ./styles/globals.scss ***!
  \*****************************/
/***/ (() => {



/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "nookies":
/*!**************************!*\
  !*** external "nookies" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("nookies");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-toastify":
/*!*********************************!*\
  !*** external "react-toastify" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-toastify");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./src/pages/_app.tsx"));
module.exports = __webpack_exports__;

})();